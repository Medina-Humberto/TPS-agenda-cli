"""Servidor web de la Agenda (solo biblioteca estándar).

Uso:  python -m web.server [--port 8000]
"""
import argparse
import json
import mimetypes
import os
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

from services.contact_manager import ContactManager
from services.image_store import UPLOAD_DIR, eliminar_imagen, guardar_imagen

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(BASE_DIR, "static")
CAMPOS = ["nombre", "apellido", "telefono", "email", "categoria"]

manager = ContactManager()
lock = threading.Lock()  # evita escrituras simultáneas sobre el CSV


class Handler(BaseHTTPRequestHandler):
    # ---------- utilidades ----------
    def _json(self, datos, status=200):
        cuerpo = json.dumps(datos, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(cuerpo)))
        self.end_headers()
        self.wfile.write(cuerpo)

    def _error(self, mensaje, status=400):
        self._json({"error": mensaje}, status)

    def _leer_json(self):
        largo = int(self.headers.get("Content-Length") or 0)
        if largo > 4 * 1024 * 1024:
            raise ValueError("La solicitud es demasiado grande.")
        try:
            return json.loads(self.rfile.read(largo) or b"{}")
        except json.JSONDecodeError:
            raise ValueError("JSON inválido.")

    def _archivo(self, carpeta, relativa):
        ruta = os.path.realpath(os.path.join(carpeta, relativa))
        if not ruta.startswith(os.path.realpath(carpeta) + os.sep) or not os.path.isfile(ruta):
            return self._error("No encontrado", 404)
        tipo = mimetypes.guess_type(ruta)[0] or "application/octet-stream"
        with open(ruta, "rb") as f:
            datos = f.read()
        self.send_response(200)
        self.send_header("Content-Type", tipo)
        self.send_header("Content-Length", str(len(datos)))
        self.end_headers()
        self.wfile.write(datos)

    def _id_de_ruta(self, ruta):
        partes = ruta.strip("/").split("/")
        if len(partes) == 3 and partes[:2] == ["api", "contactos"] and partes[2].isdigit():
            return partes[2]
        return None

    def log_message(self, fmt, *args):
        print(f"[{self.log_date_time_string()}] {fmt % args}")

    # ---------- GET ----------
    def do_GET(self):
        ruta = urlparse(self.path).path
        if ruta == "/":
            return self._archivo(STATIC_DIR, "index.html")
        if ruta.startswith("/static/"):
            return self._archivo(STATIC_DIR, ruta[len("/static/"):])
        if ruta.startswith("/uploads/"):
            return self._archivo(UPLOAD_DIR, ruta[len("/uploads/"):])
        if ruta == "/api/contactos":
            with lock:
                return self._json(manager.list_all())
        if ruta == "/api/export":
            with lock:
                manager.export_csv("agenda_export.csv")
            with open("agenda_export.csv", "rb") as f:
                datos = f.read()
            self.send_response(200)
            self.send_header("Content-Type", "text/csv; charset=utf-8")
            self.send_header("Content-Disposition", 'attachment; filename="agenda.csv"')
            self.send_header("Content-Length", str(len(datos)))
            self.end_headers()
            self.wfile.write(datos)
            return
        self._error("No encontrado", 404)

    # ---------- POST (crear) ----------
    def do_POST(self):
        if urlparse(self.path).path != "/api/contactos":
            return self._error("No encontrado", 404)
        imagen = ""
        try:
            datos = self._leer_json()
            valores = {k: str(datos.get(k, "")).strip() for k in CAMPOS}
            with lock:
                if datos.get("imagen_data"):
                    imagen = guardar_imagen(datos["imagen_data"])
                try:
                    c = manager.add(**valores, imagen=imagen)
                except ValueError:
                    eliminar_imagen(imagen)  # no dejar huérfana la imagen
                    raise
            self._json(c.to_dict(), 201)
        except ValueError as e:
            self._error(str(e))

    # ---------- PUT (actualizar) ----------
    def do_PUT(self):
        id_ = self._id_de_ruta(urlparse(self.path).path)
        if not id_:
            return self._error("No encontrado", 404)
        nueva = ""
        try:
            datos = self._leer_json()
            cambios = {k: str(datos[k]).strip() for k in CAMPOS if k in datos}
            with lock:
                actual = manager.get(id_)
                if not actual:
                    return self._error("Contacto no encontrado", 404)
                anterior = actual.get("imagen", "")
                if datos.get("imagen_data"):
                    nueva = guardar_imagen(datos["imagen_data"])
                    cambios["imagen"] = nueva
                elif datos.get("quitar_imagen"):
                    cambios["imagen"] = ""
                try:
                    manager.update(id_, cambios)
                except ValueError:
                    eliminar_imagen(nueva)
                    raise
                if "imagen" in cambios:
                    eliminar_imagen(anterior)
                self._json(manager.get(id_))
        except ValueError as e:
            self._error(str(e))

    # ---------- DELETE ----------
    def do_DELETE(self):
        id_ = self._id_de_ruta(urlparse(self.path).path)
        if not id_:
            return self._error("No encontrado", 404)
        with lock:
            c = manager.get(id_)
            if not c:
                return self._error("Contacto no encontrado", 404)
            manager.delete(id_, confirm=True)
            eliminar_imagen(c.get("imagen", ""))
        self._json({"ok": True})


def main():
    parser = argparse.ArgumentParser(description="Agenda web")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--host", default="127.0.0.1")
    args = parser.parse_args()
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    servidor = ThreadingHTTPServer((args.host, args.port), Handler)
    print(f"Agenda disponible en http://{args.host}:{args.port}  (Ctrl+C para detener)")
    try:
        servidor.serve_forever()
    except KeyboardInterrupt:
        print("\nServidor detenido.")


if __name__ == "__main__":
    main()
