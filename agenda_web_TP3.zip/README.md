# Agenda de Contactos (CLI + Web)

Trabajo Práctico Integrador TP-3C. Actividad Práctica 2: interfaz web sobre la agenda del TP1.

## Requisitos
Python 3.8 o superior. Sin dependencias externas.

## Interfaz web (Actividad Práctica 2)

Iniciar el servidor desde la carpeta del proyecto:

    python -m web.server            # abre en http://127.0.0.1:8000
    python -m web.server --port 8080

Funciones:
- Ventana (modal) para registrar y editar contactos, con validación de email y teléfono.
- CRUD completo: crear, listar, editar y eliminar (con confirmación).
- Imagen de perfil por contacto (PNG, JPG, GIF o WEBP). Se recorta/redimensiona a 256 px en el
  navegador y se guarda en `uploads/`. Si no hay imagen se muestran las iniciales.
- Persistencia en `agenda.csv` (columnas: id, nombre, apellido, telefono, email, categoria, imagen).
  Al abrir la página se leen y muestran los contactos guardados.
- Búsqueda por texto, filtro por categoría y botón para exportar el CSV.

### Estilos con Tailwind CSS (Actividad Práctica 3)

La interfaz usa **Tailwind CSS v4** con el script de desarrollo, incluido en `web/static/index.html`:

    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>

Todo el diseño (tarjetas, formulario modal, botones, grilla responsive y modo oscuro con `dark:`) se
hace con clases utilitarias de Tailwind, tanto en el HTML como en los elementos que genera `app.js`.
Ya no existe un archivo CSS propio. Se necesita conexión a internet para cargar el script.

**Para producción** el script de desarrollo no debe usarse; hay que compilar el CSS con npm:

    npm install tailwindcss @tailwindcss/cli
    echo '@import "tailwindcss";' > web/static/input.css
    npx @tailwindcss/cli -i web/static/input.css -o web/static/styles.css --minify

y en `index.html` reemplazar el `<script>` de Tailwind por
`<link rel="stylesheet" href="/static/styles.css">`.

Estructura:

    web/server.py            servidor HTTP + API REST (/api/contactos)
    web/static/              index.html (Tailwind) y app.js
    services/image_store.py  validación y guardado de imágenes
    services/contact_manager.py  lógica de contactos y CSV (compartida con la CLI)
    uploads/                 imágenes de los contactos

## CLI (TP1)

## Ejemplos

Agregar:
python -m cli.main add --nombre Ana --apellido Perez --telefono +5493811111111 --email ana@gmail.com --categoria Personal

Listar:
python -m cli.main list

Buscar:
python -m cli.main show 1
python -m cli.main show Ana

Eliminar:
python -m cli.main delete 1

Actualizar:
python -m cli.main update 1 --email nuevo@gmail.com

Exportar:
python -m cli.main export --output respaldo.csv

Importar:
python -m cli.main import --file valid_contacts.csv --on-duplicate skip

Las opciones de duplicados son skip, overwrite y append.

## CSV
Las columnas obligatorias son:
nombre, apellido, telefono, email, categoria

## Tests
python -m unittest discover
