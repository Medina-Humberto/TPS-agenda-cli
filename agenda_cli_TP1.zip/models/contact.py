from dataclasses import dataclass

@dataclass
class Contacto:
    id: int
    nombre: str
    apellido: str
    telefono: str
    email: str
    categoria: str

    def to_dict(self):
        return {
            "id": str(self.id),
            "nombre": self.nombre,
            "apellido": self.apellido,
            "telefono": self.telefono,
            "email": self.email,
            "categoria": self.categoria,
        }
