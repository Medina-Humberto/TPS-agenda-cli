# Agenda CLI Profesional

Trabajo Práctico Integrador TP-3C.

## Requisitos
Python 3.

## Ejemplos

Agregar:
python -m cli.main add --nombre Ana --apellido Perez --telefono +5493811111111 --email ana@gmail.com --categoria Personal

Listar:
python -m cli.main list

Buscar:
python -m cli.main show 1
python -m cli.main show Ana

Eliminar:
python -m cli.main delete 1

Actualizar:
python -m cli.main update 1 --email nuevo@gmail.com

Exportar:
python -m cli.main export --output respaldo.csv

Importar:
python -m cli.main import --file valid_contacts.csv --on-duplicate skip

Las opciones de duplicados son skip, overwrite y append.

## CSV
Las columnas obligatorias son:
nombre, apellido, telefono, email, categoria

## Tests
python -m unittest discover
