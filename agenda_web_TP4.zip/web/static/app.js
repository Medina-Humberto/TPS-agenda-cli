"use strict";

const $ = (id) => document.getElementById(id);
const API = "/api/contactos";

let contactos = [];
let editandoId = null;     // null = creando
let imagenNueva = null;    // data URL de la imagen elegida
let quitarImagen = false;
let imagenActual = "";     // archivo actual del contacto en edición
let idAEliminar = null;

// ---------- utilidades ----------
const INVALID = ["border-red-500!"]; // clase Tailwind para campos con error
const EMAIL_RE = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
const TEL_RE = /^\+?[0-9]+$/;
const COLORES = ["bg-indigo-600", "bg-cyan-600", "bg-emerald-600", "bg-amber-600", "bg-pink-600", "bg-violet-600", "bg-red-600", "bg-teal-600"];
const BTN_GHOST_SM = "rounded-lg border border-slate-300 px-3 py-1.5 text-sm font-semibold transition hover:bg-slate-100 focus:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 dark:border-slate-700 dark:hover:bg-slate-800";

function el(tag, props = {}, ...hijos) {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === "class") n.className = v;
    else if (k === "text") n.textContent = v;
    else if (k.startsWith("on")) n.addEventListener(k.slice(2), v);
    else n.setAttribute(k, v);
  }
  hijos.flat().forEach((h) => n.append(h));
  return n;
}

function toast(msg, esError = false) {
  const t = $("toast");
  t.textContent = msg;
  t.className = "fixed bottom-6 left-1/2 z-20 -translate-x-1/2 rounded-lg px-5 py-3 text-sm text-white shadow-lg " +
    (esError ? "bg-red-600" : "bg-slate-900");
  t.hidden = false;
  clearTimeout(toast._t);
  toast._t = setTimeout(() => (t.hidden = true), 3000);
}

async function api(url, opciones = {}) {
  const resp = await fetch(url, {
    headers: { "Content-Type": "application/json" },
    ...opciones,
  });
  const datos = await resp.json().catch(() => ({}));
  if (!resp.ok) throw new Error(datos.error || "Error inesperado");
  return datos;
}

function avatar(c) {
  const base = "grid size-14 shrink-0 place-items-center overflow-hidden rounded-full text-lg font-bold text-white ";
  if (c.imagen) {
    return el("div", { class: base + "bg-slate-200", "aria-hidden": "true" },
      el("img", { src: "/uploads/" + encodeURIComponent(c.imagen), alt: "", loading: "lazy", class: "size-full object-cover" }));
  }
  const iniciales = ((c.nombre || "?")[0] + ((c.apellido || "")[0] || "")).toUpperCase();
  return el("div", { class: base + COLORES[(parseInt(c.id, 10) || 0) % COLORES.length], "aria-hidden": "true", text: iniciales });
}

// ---------- listado ----------
async function cargar() {
  try {
    contactos = await api(API);
    actualizarCategorias();
    render();
  } catch (e) {
    toast(e.message, true);
  }
}

function actualizarCategorias() {
  const sel = $("filtro-categoria");
  const actual = sel.value;
  const cats = [...new Set(contactos.map((c) => c.categoria).filter(Boolean))].sort();
  sel.replaceChildren(el("option", { value: "", text: "Todas las categorías" }),
    ...cats.map((c) => el("option", { value: c, text: c })));
  sel.value = cats.includes(actual) ? actual : "";
}

function render() {
  const q = $("buscar").value.trim().toLowerCase();
  const cat = $("filtro-categoria").value;
  const visibles = contactos.filter((c) =>
    (!cat || c.categoria === cat) &&
    (!q || [c.nombre, c.apellido, c.telefono, c.email].some((v) => v.toLowerCase().includes(q))));

  const lista = $("lista");
  lista.replaceChildren(...visibles.map(tarjeta));
  $("vacio").hidden = visibles.length > 0;
  $("contador").textContent = `${visibles.length} de ${contactos.length} contactos`;
}

function tarjeta(c) {
  return el("article", { class: "flex flex-col gap-3.5 rounded-2xl bg-white p-5 shadow-sm ring-1 ring-slate-200 transition hover:shadow-md dark:bg-slate-900 dark:ring-slate-800" },
    el("div", { class: "flex items-center gap-3.5" },
      avatar(c),
      el("div", { class: "min-w-0" },
        el("h3", { class: "break-words text-lg font-semibold leading-tight", text: `${c.nombre} ${c.apellido}` }),
        el("span", { class: "mt-1 inline-block rounded-full bg-indigo-100 px-2.5 py-0.5 text-xs font-semibold text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300", text: c.categoria }))),
    el("ul", { class: "grid gap-1 break-all text-sm text-slate-600 dark:text-slate-400" },
      el("li", {}, "📞 ", el("a", { href: "tel:" + c.telefono, class: "hover:text-indigo-600 hover:underline", text: c.telefono })),
      el("li", {}, "✉️ ", el("a", { href: "mailto:" + c.email, class: "hover:text-indigo-600 hover:underline", text: c.email }))),
    el("div", { class: "mt-auto flex gap-2" },
      el("button", { class: BTN_GHOST_SM, type: "button", text: "Editar", onclick: () => abrirForm(c) }),
      el("button", { class: BTN_GHOST_SM + " hover:text-red-600", type: "button", text: "Eliminar", onclick: () => pedirBorrado(c) })));
}

// ---------- formulario ----------
function pintarPreview() {
  const prev = $("preview");
  prev.replaceChildren();
  const src = imagenNueva || (!quitarImagen && imagenActual ? "/uploads/" + encodeURIComponent(imagenActual) : "");
  if (src) {
    prev.append(el("img", { src, alt: "", class: "size-full object-cover" }));
  } else {
    const n = ($("nombre").value[0] || "?").toUpperCase();
    const a = ($("apellido").value[0] || "").toUpperCase();
    prev.textContent = n + a;
  }
  $("quitar-imagen").hidden = !src;
}

function abrirForm(c = null) {
  editandoId = c ? c.id : null;
  imagenNueva = null;
  quitarImagen = false;
  imagenActual = c ? c.imagen : "";
  $("modal-titulo").textContent = c ? "Editar contacto" : "Nuevo contacto";
  for (const campo of ["nombre", "apellido", "telefono", "email", "categoria"]) {
    $(campo).value = c ? c[campo] : "";
    $(campo).classList.remove(...INVALID);
  }
  $("imagen").value = "";
  $("form-error").hidden = true;
  pintarPreview();
  $("modal").showModal();
  $("nombre").focus();
}

function validar() {
  const errores = [];
  const v = (id) => $(id).value.trim();
  const marcar = (id, malo) => $(id).classList.toggle(INVALID[0], malo);

  marcar("nombre", !v("nombre")); marcar("apellido", !v("apellido")); marcar("categoria", !v("categoria"));
  if (!v("nombre") || !v("apellido")) errores.push("El nombre y el apellido son obligatorios.");
  if (!v("categoria")) errores.push("La categoría es obligatoria.");
  const telMal = !TEL_RE.test(v("telefono")); marcar("telefono", telMal);
  if (telMal) errores.push("El teléfono solo puede contener números y opcionalmente '+' al inicio.");
  const mailMal = !EMAIL_RE.test(v("email")); marcar("email", mailMal);
  if (mailMal) errores.push("El email no tiene un formato válido.");
  return errores;
}

// Reduce la imagen a 256 px para que el CSV/uploads queden livianos.
function redimensionar(archivo) {
  return new Promise((resolve, reject) => {
    if (!/^image\/(png|jpeg|gif|webp)$/.test(archivo.type)) return reject(new Error("Formato no soportado. Usá PNG, JPG, GIF o WEBP."));
    if (archivo.size > 8 * 1024 * 1024) return reject(new Error("La imagen es demasiado grande (máx. 8 MB)."));
    const url = URL.createObjectURL(archivo);
    const img = new Image();
    img.onload = () => {
      const lado = Math.min(256, Math.min(img.width, img.height));
      const canvas = document.createElement("canvas");
      canvas.width = canvas.height = lado;
      const recorte = Math.min(img.width, img.height);
      canvas.getContext("2d").drawImage(img, (img.width - recorte) / 2, (img.height - recorte) / 2, recorte, recorte, 0, 0, lado, lado);
      URL.revokeObjectURL(url);
      resolve(canvas.toDataURL("image/jpeg", 0.88));
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error("No se pudo leer la imagen.")); };
    img.src = url;
  });
}

$("imagen").addEventListener("change", async (e) => {
  const archivo = e.target.files[0];
  if (!archivo) return;
  try {
    imagenNueva = await redimensionar(archivo);
    quitarImagen = false;
    $("form-error").hidden = true;
    pintarPreview();
  } catch (err) {
    e.target.value = "";
    mostrarError(err.message);
  }
});

$("quitar-imagen").addEventListener("click", () => {
  imagenNueva = null;
  quitarImagen = true;
  $("imagen").value = "";
  pintarPreview();
});

["nombre", "apellido"].forEach((id) => $(id).addEventListener("input", () => { if (!imagenNueva && !imagenActual) pintarPreview(); }));

function mostrarError(msg) {
  const box = $("form-error");
  box.textContent = msg;
  box.hidden = false;
}

$("form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const errores = validar();
  if (errores.length) return mostrarError(errores.join(" "));

  const cuerpo = {};
  for (const campo of ["nombre", "apellido", "telefono", "email", "categoria"]) cuerpo[campo] = $(campo).value.trim();
  if (imagenNueva) cuerpo.imagen_data = imagenNueva;
  if (quitarImagen) cuerpo.quitar_imagen = true;

  const btn = $("guardar");
  btn.disabled = true;
  try {
    if (editandoId) await api(`${API}/${editandoId}`, { method: "PUT", body: JSON.stringify(cuerpo) });
    else await api(API, { method: "POST", body: JSON.stringify(cuerpo) });
    $("modal").close();
    toast(editandoId ? "Contacto actualizado" : "Contacto registrado");
    await cargar();
  } catch (err) {
    mostrarError(err.message);
  } finally {
    btn.disabled = false;
  }
});

$("cancelar").addEventListener("click", () => $("modal").close());
$("btn-nuevo").addEventListener("click", () => abrirForm());

// ---------- borrado ----------
function pedirBorrado(c) {
  idAEliminar = c.id;
  $("confirmar-texto").textContent = `¿Seguro que querés eliminar a ${c.nombre} ${c.apellido}? Esta acción no se puede deshacer.`;
  $("confirmar").showModal();
}
$("confirmar-no").addEventListener("click", () => $("confirmar").close());
$("confirmar-si").addEventListener("click", async () => {
  try {
    await api(`${API}/${idAEliminar}`, { method: "DELETE" });
    toast("Contacto eliminado");
    await cargar();
  } catch (err) {
    toast(err.message, true);
  }
  $("confirmar").close();
});

// ---------- filtros ----------
$("buscar").addEventListener("input", render);
$("filtro-categoria").addEventListener("change", render);

cargar();
