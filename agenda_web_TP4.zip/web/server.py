"""Servidor web + API REST de la Agenda (solo biblioteca estándar).

Uso:  python -m web.server [--port 8000]

Endpoints (ver docs/API.md):
    GET    /api/contactos            listar (filtros ?q= y ?categoria=)
    POST   /api/contactos            crear
    GET    /api/contactos/<id>       obtener uno
    PUT    /api/contactos/<id>       reemplazar (todos los campos)
    PATCH  /api/contactos/<id>       actualizar parcialmente
    DELETE /api/contactos/<id>       eliminar
    GET    /api/export               descargar CSV
"""
import argparse
import csv
import io
import json
import mimetypes
import os
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from services.contact_manager import FIELDS, ContactManager, DuplicadoError
from services.image_store import UPLOAD_DIR, eliminar_imagen, guardar_imagen

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(BASE_DIR, "static")
CAMPOS = ["nombre", "apellido", "telefono", "email", "categoria"]
MAX_BODY = 4 * 1024 * 1024

manager = ContactManager()
lock = threading.Lock()  # evita escrituras simultáneas sobre el CSV


class ApiError(Exception):
    def __init__(self, status, mensaje, headers=None):
        super().__init__(mensaje)
        self.status, self.mensaje, self.headers = status, mensaje, headers or {}


class Handler(BaseHTTPRequestHandler):
    # ---------- respuestas ----------
    def _enviar(self, status, cuerpo=b"", tipo="application/json; charset=utf-8", extra=None):
        self.send_response(status)
        if status != 204:
            self.send_header("Content-Type", tipo)
        self.send_header("Content-Length", str(len(cuerpo)))
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if cuerpo and self.command != "HEAD":
            self.wfile.write(cuerpo)

    def _json(self, datos, status=200, extra=None):
        self._enviar(status, json.dumps(datos, ensure_ascii=False).encode("utf-8"), extra=extra)

    def _leer_json(self):
        largo = int(self.headers.get("Content-Length") or 0)
        if largo > MAX_BODY:
            raise ApiError(413, "La solicitud es demasiado grande (máx. 4 MB).")
        try:
            datos = json.loads(self.rfile.read(largo) or b"{}")
        except (json.JSONDecodeError, UnicodeDecodeError):
            raise ApiError(400, "El cuerpo no es un JSON válido.")
        if not isinstance(datos, dict):
            raise ApiError(400, "El cuerpo debe ser un objeto JSON.")
        return datos

    def log_message(self, fmt, *args):
        print(f"[{self.log_date_time_string()}] {fmt % args}")

    # ---------- archivos estáticos ----------
    def _archivo(self, carpeta, relativa):
        ruta = os.path.realpath(os.path.join(carpeta, relativa))
        if not ruta.startswith(os.path.realpath(carpeta) + os.sep) or not os.path.isfile(ruta):
            raise ApiError(404, "No encontrado.")
        with open(ruta, "rb") as f:
            datos = f.read()
        self._enviar(200, datos, mimetypes.guess_type(ruta)[0] or "application/octet-stream")

    # ---------- despacho ----------
    def _despachar(self):
        url = urlparse(self.path)
        ruta, metodo = url.path.rstrip("/") or "/", self.command
        try:
            if not ruta.startswith("/api"):
                if metodo not in ("GET", "HEAD"):
                    raise ApiError(405, "Método no permitido.", {"Allow": "GET, HEAD"})
                if ruta == "/":
                    return self._archivo(STATIC_DIR, "index.html")
                if ruta.startswith("/static/"):
                    return self._archivo(STATIC_DIR, ruta[len("/static/"):])
                if ruta.startswith("/uploads/"):
                    return self._archivo(UPLOAD_DIR, ruta[len("/uploads/"):])
                raise ApiError(404, "No encontrado.")

            partes = ruta.strip("/").split("/")  # ['api', 'contactos', '<id>']
            if partes == ["api", "export"]:
                self._solo(metodo, ["GET"])
                return self._exportar()
            if partes == ["api", "contactos"]:
                self._solo(metodo, ["GET", "POST"])
                return self._listar(parse_qs(url.query)) if metodo == "GET" else self._crear()
            if len(partes) == 3 and partes[:2] == ["api", "contactos"]:
                self._solo(metodo, ["GET", "PUT", "PATCH", "DELETE"])
                id_ = partes[2]
                if metodo == "GET":
                    return self._obtener(id_)
                if metodo == "DELETE":
                    return self._eliminar(id_)
                return self._actualizar(id_, parcial=(metodo == "PATCH"))
            raise ApiError(404, "Recurso no encontrado.")
        except ApiError as e:
            self._json({"error": e.mensaje}, e.status, e.headers)
        except DuplicadoError as e:
            self._json({"error": str(e)}, 409)
        except ValueError as e:
            self._json({"error": str(e)}, 400)
        except Exception as e:  # no exponer detalles internos
            print("Error interno:", repr(e))
            self._json({"error": "Error interno del servidor."}, 500)

    @staticmethod
    def _solo(metodo, permitidos):
        if metodo not in permitidos:
            raise ApiError(405, "Método no permitido.", {"Allow": ", ".join(permitidos)})

    do_GET = do_POST = do_PUT = do_PATCH = do_DELETE = do_HEAD = _despachar

    # ---------- operaciones ----------
    def _listar(self, qs):
        q = (qs.get("q", [""])[0]).strip().lower()
        cat = (qs.get("categoria", [""])[0]).strip().lower()
        with lock:
            datos = manager.list_all()
        if cat:
            datos = [c for c in datos if c["categoria"].lower() == cat]
        if q:
            datos = [c for c in datos
                     if any(q in c[k].lower() for k in ("nombre", "apellido", "telefono", "email"))]
        self._json(datos, extra={"X-Total-Count": str(len(datos))})

    def _obtener(self, id_):
        with lock:
            c = manager.get(id_) if id_.isdigit() else None
        if not c:
            raise ApiError(404, "Contacto no encontrado.")
        self._json(c)

    def _crear(self):
        datos = self._leer_json()
        faltan = [k for k in CAMPOS if not str(datos.get(k, "")).strip()]
        if faltan:
            raise ApiError(400, "Faltan campos obligatorios: " + ", ".join(faltan) + ".")
        valores = {k: str(datos[k]).strip() for k in CAMPOS}
        imagen = ""
        with lock:
            if datos.get("imagen_data"):
                imagen = guardar_imagen(datos["imagen_data"])
            try:
                c = manager.add(**valores, imagen=imagen)
            except ValueError:
                eliminar_imagen(imagen)  # no dejar huérfana la imagen
                raise
        self._json(c.to_dict(), 201, {"Location": f"/api/contactos/{c.id}"})

    def _actualizar(self, id_, parcial):
        datos = self._leer_json()
        if not parcial:
            faltan = [k for k in CAMPOS if not str(datos.get(k, "")).strip()]
            if faltan:
                raise ApiError(400, "PUT requiere todos los campos. Faltan: " + ", ".join(faltan) + ". Usá PATCH para cambios parciales.")
        cambios = {k: str(datos[k]).strip() for k in CAMPOS if k in datos}
        nueva = ""
        with lock:
            actual = manager.get(id_) if id_.isdigit() else None
            if not actual:
                raise ApiError(404, "Contacto no encontrado.")
            anterior = actual.get("imagen", "")
            if datos.get("imagen_data"):
                nueva = guardar_imagen(datos["imagen_data"])
                cambios["imagen"] = nueva
            elif datos.get("quitar_imagen"):
                cambios["imagen"] = ""
            try:
                manager.update(id_, cambios)
            except ValueError:
                eliminar_imagen(nueva)
                raise
            if "imagen" in cambios:
                eliminar_imagen(anterior)
            self._json(manager.get(id_))

    def _eliminar(self, id_):
        with lock:
            c = manager.get(id_) if id_.isdigit() else None
            if not c:
                raise ApiError(404, "Contacto no encontrado.")
            manager.delete(id_, confirm=True)
            eliminar_imagen(c.get("imagen", ""))
        self._enviar(204)

    def _exportar(self):
        with lock:
            filas = manager.list_all()
        buf = io.StringIO()
        w = csv.DictWriter(buf, fieldnames=FIELDS, extrasaction="ignore")
        w.writeheader()
        w.writerows(filas)
        self._enviar(200, buf.getvalue().encode("utf-8"), "text/csv; charset=utf-8",
                     {"Content-Disposition": 'attachment; filename="agenda.csv"'})


def crear_servidor(host="127.0.0.1", port=8000):
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    return ThreadingHTTPServer((host, port), Handler)


def main():
    parser = argparse.ArgumentParser(description="Agenda web + API REST")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--host", default="127.0.0.1")
    args = parser.parse_args()
    servidor = crear_servidor(args.host, args.port)
    print(f"Agenda disponible en http://{args.host}:{args.port}  (Ctrl+C para detener)")
    try:
        servidor.serve_forever()
    except KeyboardInterrupt:
        print("\nServidor detenido.")


if __name__ == "__main__":
    main()
