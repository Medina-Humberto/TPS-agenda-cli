import argparse
from services.contact_manager import ContactManager

def main():
    parser = argparse.ArgumentParser(description="Agenda CLI de Contactos")
    sub = parser.add_subparsers(dest="comando")

    p = sub.add_parser("add", help="Crear contacto")
    p.add_argument("--nombre", required=True)
    p.add_argument("--apellido", required=True)
    p.add_argument("--telefono", required=True)
    p.add_argument("--email", required=True)
    p.add_argument("--categoria", required=True)

    sub.add_parser("list", help="Listar contactos")

    p = sub.add_parser("show", help="Mostrar contacto por ID o nombre")
    p.add_argument("identificador")

    p = sub.add_parser("delete", help="Eliminar contacto")
    p.add_argument("identificador")

    p = sub.add_parser("update", help="Actualizar contacto")
    p.add_argument("id")
    p.add_argument("--nombre")
    p.add_argument("--apellido")
    p.add_argument("--telefono")
    p.add_argument("--email")
    p.add_argument("--categoria")

    p = sub.add_parser("export", help="Exportar CSV")
    p.add_argument("--output", required=True)

    p = sub.add_parser("import", help="Importar CSV")
    p.add_argument("--file", required=True)
    p.add_argument("--on-duplicate", choices=["skip", "overwrite", "append"], default="skip")

    args = parser.parse_args()
    manager = ContactManager()

    try:
        if args.comando == "add":
            c = manager.add(args.nombre, args.apellido, args.telefono, args.email, args.categoria)
            print(f"Contacto '{c.nombre} {c.apellido}' registrado con ID {c.id}.")

        elif args.comando == "list":
            contactos = manager.list_all()
            if not contactos:
                print("La agenda está vacía.")
                return
            for c in contactos:
                print(f"{c['id']} | {c['nombre']} {c['apellido']} | {c['telefono']} | {c['email']} | {c['categoria']}")

        elif args.comando == "show":
            c = manager.show(args.identificador)
            print(c if c else "Contacto no encontrado.")

        elif args.comando == "delete":
            c = manager.show(args.identificador)
            if not c:
                print("Contacto no encontrado.")
                return
            respuesta = input(f"¿Eliminar a {c['nombre']} {c['apellido']}? [y/N]: ").strip().lower()
            print("Contacto eliminado." if manager.delete(args.identificador, respuesta == "y") else "Operación cancelada.")

        elif args.comando == "update":
            cambios = {k: v for k, v in vars(args).items() if k in ["nombre","apellido","telefono","email","categoria"] and v is not None}
            print("Contacto actualizado." if manager.update(args.id, cambios) else "Contacto no encontrado.")

        elif args.comando == "export":
            manager.export_csv(args.output)
            print(f"Exportación completada: {args.output}")

        elif args.comando == "import":
            nuevos, errores = manager.import_csv(args.file, args.on_duplicate)
            print(f"Importación completada: {nuevos} contactos añadidos.")
            if errores:
                print(f"Se registraron {len(errores)} incidencias en import_errors.log.")

        else:
            parser.print_help()

    except (ValueError, FileNotFoundError) as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()
