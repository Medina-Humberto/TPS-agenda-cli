import re

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
PHONE_RE = re.compile(r"^\+?[0-9]+$")

def validar_email(email):
    return bool(EMAIL_RE.fullmatch(email))

def validar_telefono(telefono):
    return bool(PHONE_RE.fullmatch(telefono))
