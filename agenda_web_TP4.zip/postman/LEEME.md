# Probar la API con Postman

1. Iniciar el servidor: `python -m web.server`
2. En Postman: **Import** → seleccionar `Agenda_API.postman_collection.json`.
3. La variable `base_url` ya apunta a `http://127.0.0.1:8000` (editable en la pestaña *Variables* de la colección).
4. Ejecutar request por request, o toda la colección con **Run collection** (respetar el orden: los pasos 1 y 2 guardan los ids que usan los siguientes).
5. Cada request trae tests (pestaña *Scripts → Post-response*) que verifican código de estado y contenido; los resultados aparecen en *Test Results*.

## Capturas a adjuntar (guardar en `docs/capturas/`)

Tomar una captura por cada una, mostrando **URL, método, cuerpo, código de estado y respuesta**:

- `01_crear_201.png` – request 1 (POST) con respuesta 201
- `02_listar_200.png` – request 3 (GET lista)
- `03_obtener_200.png` – request 5
- `04_put_200.png` y `05_patch_200.png` – requests 6 y 7
- `06_error_400.png`, `07_error_409.png`, `08_error_404.png` – requests 9, 12 y 13
- `09_delete_204.png` – request 16
- `10_runner_resultado.png` – resultado del **Collection Runner** con los 18 tests en verde
