import csv
import os
from models.contact import Contacto
from utils.validation import validar_email, validar_telefono

DB_FILE = "agenda.csv"
FIELDS = ["id", "nombre", "apellido", "telefono", "email", "categoria", "imagen"]
REQUIRED_COLUMNS = ["nombre", "apellido", "telefono", "email", "categoria"]

class DuplicadoError(ValueError):
    """Ya existe un contacto con ese email o teléfono."""


class ContactManager:
    def __init__(self, db_file=DB_FILE):
        self.db_file = db_file

    def cargar(self):
        if not os.path.exists(self.db_file):
            return []
        with open(self.db_file, "r", newline="", encoding="utf-8") as f:
            filas = list(csv.DictReader(f))
        for fila in filas:
            fila.setdefault("imagen", "")
            if fila["imagen"] is None:
                fila["imagen"] = ""
        return filas

    def guardar(self, contactos):
        with open(self.db_file, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=FIELDS, extrasaction="ignore")
            writer.writeheader()
            writer.writerows(contactos)

    def siguiente_id(self, contactos):
        return max((int(c["id"]) for c in contactos), default=0) + 1

    def add(self, nombre, apellido, telefono, email, categoria, imagen=""):
        contactos = self.cargar()
        nombre, apellido = nombre.strip(), apellido.strip()
        if not nombre or not apellido:
            raise ValueError("El nombre y el apellido son obligatorios.")
        if not validar_email(email):
            raise ValueError("El email no tiene un formato válido.")
        if not validar_telefono(telefono):
            raise ValueError("El teléfono solo puede contener números y opcionalmente '+'.")
        if any(c["email"].lower() == email.lower() or c["telefono"] == telefono for c in contactos):
            raise DuplicadoError("Ya existe un contacto con ese email o teléfono.")
        contacto = Contacto(self.siguiente_id(contactos), nombre, apellido, telefono, email, categoria, imagen)
        contactos.append(contacto.to_dict())
        self.guardar(contactos)
        return contacto

    def list_all(self):
        return self.cargar()

    def get(self, id_contacto):
        for c in self.cargar():
            if c["id"] == str(id_contacto):
                return c
        return None

    def show(self, identificador):
        contactos = self.cargar()
        for c in contactos:
            if c["id"] == str(identificador):
                return c
        for c in contactos:
            if c["nombre"].lower() == str(identificador).lower():
                return c
        return None

    def delete(self, identificador, confirm=False):
        contactos = self.cargar()
        encontrado = self.show(identificador)
        if not encontrado:
            return False
        if not confirm:
            return None
        contactos = [c for c in contactos if c["id"] != encontrado["id"]]
        self.guardar(contactos)
        return True

    def update(self, identificador, cambios):
        contactos = self.cargar()
        encontrado = None
        for c in contactos:
            if c["id"] == str(identificador):
                encontrado = c
                break
        if not encontrado:
            return False
        for campo, valor in cambios.items():
            if campo not in FIELDS or campo == "id":
                continue
            if campo == "email" and not validar_email(valor):
                raise ValueError("Email inválido.")
            if campo == "telefono" and not validar_telefono(valor):
                raise ValueError("Teléfono inválido.")
            if campo in ("nombre", "apellido") and not str(valor).strip():
                raise ValueError("El nombre y el apellido no pueden quedar vacíos.")
            if campo in ("email", "telefono"):
                for otro in contactos:
                    if otro is encontrado:
                        continue
                    if (campo == "email" and otro["email"].lower() == valor.lower()) or \
                       (campo == "telefono" and otro["telefono"] == valor):
                        raise DuplicadoError("Ya existe otro contacto con ese email o teléfono.")
            encontrado[campo] = valor
        self.guardar(contactos)
        return True

    def export_csv(self, output):
        contactos = self.cargar()
        with open(output, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=FIELDS, extrasaction="ignore")
            writer.writeheader()
            writer.writerows(contactos)

    def import_csv(self, archivo, on_duplicate="skip"):
        if not os.path.exists(archivo):
            raise FileNotFoundError(f"No existe: {archivo}")

        contactos = self.cargar()
        existentes_email = {c["email"].lower() for c in contactos}
        existentes_tel = {c["telefono"] for c in contactos}
        max_id = self.siguiente_id(contactos) - 1
        nuevos = 0
        errores = []

        with open(archivo, "r", newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            if not set(REQUIRED_COLUMNS).issubset(reader.fieldnames or []):
                raise ValueError("El CSV no contiene todas las columnas obligatorias.")

            for numero, row in enumerate(reader, start=2):
                nombre = row.get("nombre", "").strip()
                apellido = row.get("apellido", "").strip()
                telefono = row.get("telefono", "").strip()
                email = row.get("email", "").strip()
                categoria = row.get("categoria", "").strip()

                razones = []
                if not nombre or not apellido:
                    razones.append("nombre/apellido vacío")
                if not validar_email(email):
                    razones.append("email inválido")
                if not validar_telefono(telefono):
                    razones.append("teléfono inválido")

                duplicado = email.lower() in existentes_email or telefono in existentes_tel
                if razones:
                    errores.append(f"Fila {numero}: {', '.join(razones)}")
                    continue

                if duplicado:
                    if on_duplicate == "skip":
                        errores.append(f"Fila {numero}: duplicado, omitido")
                        continue
                    elif on_duplicate == "overwrite":
                        for c in contactos:
                            if c["email"].lower() == email.lower() or c["telefono"] == telefono:
                                c.update({"nombre": nombre, "apellido": apellido, "telefono": telefono, "email": email, "categoria": categoria})
                        continue
                    elif on_duplicate == "append":
                        pass

                max_id += 1
                contactos.append({
                    "id": str(max_id),
                    "nombre": nombre,
                    "apellido": apellido,
                    "telefono": telefono,
                    "email": email,
                    "categoria": categoria,
                    "imagen": (row.get("imagen") or "").strip(),
                })
                existentes_email.add(email.lower())
                existentes_tel.add(telefono)
                nuevos += 1

        self.guardar(contactos)
        with open("import_errors.log", "w", encoding="utf-8") as log:
            log.write("\n".join(errores))
        return nuevos, errores
