"""Guarda y elimina las imágenes de perfil de los contactos."""
import base64
import os
import uuid

UPLOAD_DIR = "uploads"
MAX_BYTES = 2 * 1024 * 1024  # 2 MB

# firma binaria -> extensión
_FIRMAS = [
    (b"\x89PNG\r\n\x1a\n", ".png"),
    (b"\xff\xd8\xff", ".jpg"),
    (b"GIF87a", ".gif"),
    (b"GIF89a", ".gif"),
]


def _extension(datos):
    for firma, ext in _FIRMAS:
        if datos.startswith(firma):
            return ext
    if datos[:4] == b"RIFF" and datos[8:12] == b"WEBP":
        return ".webp"
    return None


def guardar_imagen(data_url, carpeta=UPLOAD_DIR):
    """Recibe un data URL (base64), valida que sea una imagen real y la guarda.
    Devuelve el nombre del archivo generado."""
    if not data_url or "," not in data_url:
        raise ValueError("Imagen inválida.")
    try:
        datos = base64.b64decode(data_url.split(",", 1)[1], validate=True)
    except Exception:
        raise ValueError("La imagen no se pudo leer.")
    if len(datos) > MAX_BYTES:
        raise ValueError("La imagen supera el máximo de 2 MB.")
    ext = _extension(datos)
    if ext is None:
        raise ValueError("Formato no soportado. Usá PNG, JPG, GIF o WEBP.")
    os.makedirs(carpeta, exist_ok=True)
    nombre = f"{uuid.uuid4().hex}{ext}"
    with open(os.path.join(carpeta, nombre), "wb") as f:
        f.write(datos)
    return nombre


def eliminar_imagen(nombre, carpeta=UPLOAD_DIR):
    if not nombre:
        return
    ruta = os.path.join(carpeta, os.path.basename(nombre))
    if os.path.isfile(ruta):
        os.remove(ruta)
