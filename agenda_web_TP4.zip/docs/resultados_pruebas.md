# Resultados de las pruebas de la API

Ejecutadas el 2026-11-12 contra `python -m web.server` con el mismo orden y datos de la colección de Postman (`postman/Agenda_API.postman_collection.json`).

> Este archivo lo generó un script que ejecuta la colección. Las capturas de Postman van en `docs/capturas/`.

**Resultado: 18/18 pruebas correctas.**

## 1. Crear contacto (POST)

`POST {{base_url}}/api/contactos` → **201** (esperado 201) ✅

Cuerpo enviado:
```json
{
  "nombre": "Ana",
  "apellido": "Perez",
  "telefono": "+5493811111111",
  "email": "ana@gmail.com",
  "categoria": "Personal"
}
```

Respuesta:
```
{
  "id": "1",
  "nombre": "Ana",
  "apellido": "Perez",
  "telefono": "+5493811111111",
  "email": "ana@gmail.com",
  "categoria": "Personal",
  "imagen": ""
}
```

## 2. Crear contacto con imagen (POST)

`POST {{base_url}}/api/contactos` → **201** (esperado 201) ✅

Cuerpo enviado:
```json
{
  "nombre": "Juan",
  "apellido": "Gomez",
  "telefono": "3812222222",
  "email": "juan@gmail.com",
  "categoria": "Trabajo",
  "imagen_data": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg=="
}
```

Respuesta:
```
{
  "id": "2",
  "nombre": "Juan",
  "apellido": "Gomez",
  "telefono": "3812222222",
  "email": "juan@gmail.com",
  "categoria": "Trabajo",
  "imagen": "7ef56177c8334b60b55161b3852a9186.png"
}
```

## 3. Listar contactos (GET)

`GET {{base_url}}/api/contactos` → **200** (esperado 200) ✅

Respuesta:
```
[
  {
    "id": "1",
    "nombre": "Ana",
    "apellido": "Perez",
    "telefono": "+5493811111111",
    "email": "ana@gmail.com",
    "categoria": "Personal",
    "imagen": ""
  },
  {
    "id": "2",
    "nombre": "Juan",
    "apellido": "Gomez",
    "telefono": "3812222222",
    "email": "juan@gmail.com",
    "categoria": "Trabajo",
    "imagen": "7ef56177c8334b60b55161b3852a9186.png"
  }
]
```

## 4. Listar con filtro (GET ?q= &categoria=)

`GET {{base_url}}/api/contactos?q=ana&categoria=Personal` → **200** (esperado 200) ✅

Respuesta:
```
[
  {
    "id": "1",
    "nombre": "Ana",
    "apellido": "Perez",
    "telefono": "+5493811111111",
    "email": "ana@gmail.com",
    "categoria": "Personal",
    "imagen": ""
  }
]
```

## 5. Obtener contacto por id (GET)

`GET {{base_url}}/api/contactos/1` → **200** (esperado 200) ✅

Respuesta:
```
{
  "id": "1",
  "nombre": "Ana",
  "apellido": "Perez",
  "telefono": "+5493811111111",
  "email": "ana@gmail.com",
  "categoria": "Personal",
  "imagen": ""
}
```

## 6. Reemplazar contacto (PUT)

`PUT {{base_url}}/api/contactos/1` → **200** (esperado 200) ✅

Cuerpo enviado:
```json
{
  "nombre": "Anita",
  "apellido": "Perez",
  "telefono": "+5493811111111",
  "email": "ana@gmail.com",
  "categoria": "Personal"
}
```

Respuesta:
```
{
  "id": "1",
  "nombre": "Anita",
  "apellido": "Perez",
  "telefono": "+5493811111111",
  "email": "ana@gmail.com",
  "categoria": "Personal",
  "imagen": ""
}
```

## 7. Actualizar parcialmente (PATCH)

`PATCH {{base_url}}/api/contactos/1` → **200** (esperado 200) ✅

Cuerpo enviado:
```json
{
  "categoria": "Familia"
}
```

Respuesta:
```
{
  "id": "1",
  "nombre": "Anita",
  "apellido": "Perez",
  "telefono": "+5493811111111",
  "email": "ana@gmail.com",
  "categoria": "Familia",
  "imagen": ""
}
```

## 8. Quitar imagen (PATCH)

`PATCH {{base_url}}/api/contactos/2` → **200** (esperado 200) ✅

Cuerpo enviado:
```json
{
  "quitar_imagen": true
}
```

Respuesta:
```
{
  "id": "2",
  "nombre": "Juan",
  "apellido": "Gomez",
  "telefono": "3812222222",
  "email": "juan@gmail.com",
  "categoria": "Trabajo",
  "imagen": ""
}
```

## 9. Error 400 - email inválido (POST)

`POST {{base_url}}/api/contactos` → **400** (esperado 400) ✅

Cuerpo enviado:
```json
{
  "nombre": "Ana",
  "apellido": "Perez",
  "telefono": "999",
  "email": "ana@",
  "categoria": "Personal"
}
```

Respuesta:
```
{
  "error": "El email no tiene un formato válido."
}
```

## 10. Error 400 - faltan campos (POST)

`POST {{base_url}}/api/contactos` → **400** (esperado 400) ✅

Cuerpo enviado:
```json
{
  "nombre": "X"
}
```

Respuesta:
```
{
  "error": "Faltan campos obligatorios: apellido, telefono, email, categoria."
}
```

## 11. Error 400 - PUT incompleto

`PUT {{base_url}}/api/contactos/1` → **400** (esperado 400) ✅

Cuerpo enviado:
```json
{
  "nombre": "Solo"
}
```

Respuesta:
```
{
  "error": "PUT requiere todos los campos. Faltan: apellido, telefono, email, categoria. Usá PATCH para cambios parciales."
}
```

## 12. Error 409 - duplicado (POST)

`POST {{base_url}}/api/contactos` → **409** (esperado 409) ✅

Cuerpo enviado:
```json
{
  "nombre": "Ana",
  "apellido": "Perez",
  "telefono": "+5493811111111",
  "email": "ana@gmail.com",
  "categoria": "Personal"
}
```

Respuesta:
```
{
  "error": "Ya existe un contacto con ese email o teléfono."
}
```

## 13. Error 404 - contacto inexistente (GET)

`GET {{base_url}}/api/contactos/99999` → **404** (esperado 404) ✅

Respuesta:
```
{
  "error": "Contacto no encontrado."
}
```

## 14. Error 405 - método no permitido

`DELETE {{base_url}}/api/contactos` → **405** (esperado 405) ✅

Respuesta:
```
{
  "error": "Método no permitido."
}
```

## 15. Exportar CSV (GET)

`GET {{base_url}}/api/export` → **200** (esperado 200) ✅

Respuesta:
```
id,nombre,apellido,telefono,email,categoria,imagen
1,Anita,Perez,+5493811111111,ana@gmail.com,Familia,
2,Juan,Gomez,3812222222,juan@gmail.com,Trabajo,
```

## 16. Eliminar contacto (DELETE)

`DELETE {{base_url}}/api/contactos/1` → **204** (esperado 204) ✅

## 17. Eliminar contacto con imagen (DELETE)

`DELETE {{base_url}}/api/contactos/2` → **204** (esperado 204) ✅

## 18. Eliminar de nuevo - 404 (DELETE)

`DELETE {{base_url}}/api/contactos/1` → **404** (esperado 404) ✅

Respuesta:
```
{
  "error": "Contacto no encontrado."
}
```
