# Documentación de la API REST – Agenda

Base URL: `http://127.0.0.1:8000` · Formato: JSON (UTF-8) · Sin autenticación (uso local).

## Modelo de contacto

| Campo      | Tipo   | Notas                                                    |
|------------|--------|----------------------------------------------------------|
| id         | string | Lo genera el servidor                                    |
| nombre     | string | Obligatorio                                              |
| apellido   | string | Obligatorio                                              |
| telefono   | string | Obligatorio. Solo dígitos y `+` opcional al inicio. Único |
| email      | string | Obligatorio. Formato válido. Único (sin distinguir mayúsculas) |
| categoria  | string | Obligatorio                                              |
| imagen     | string | Nombre del archivo; se sirve en `/uploads/<imagen>`. `""` si no tiene |

## Endpoints

| Método | Ruta                  | Descripción                             | Éxito |
|--------|-----------------------|-----------------------------------------|-------|
| GET    | `/api/contactos`      | Lista. Filtros opcionales `?q=` (busca en nombre, apellido, teléfono, email) y `?categoria=` | 200 |
| POST   | `/api/contactos`      | Crea un contacto                        | 201 + header `Location` |
| GET    | `/api/contactos/{id}` | Obtiene un contacto                     | 200 |
| PUT    | `/api/contactos/{id}` | Reemplaza: exige los 5 campos           | 200 |
| PATCH  | `/api/contactos/{id}` | Actualiza solo los campos enviados      | 200 |
| DELETE | `/api/contactos/{id}` | Elimina (y borra su imagen)             | 204 sin cuerpo |
| GET    | `/api/export`         | Descarga todos los contactos en CSV     | 200 `text/csv` |

La respuesta de `GET /api/contactos` incluye el header `X-Total-Count`.

### Imagen
En POST, PUT y PATCH se puede enviar:
- `"imagen_data": "data:image/png;base64,...."` → asigna/reemplaza la imagen (PNG, JPG, GIF o WEBP, máx. 2 MB; se valida el contenido real, no la extensión).
- `"quitar_imagen": true` → elimina la imagen actual.

## Códigos de error

Todos los errores devuelven `{"error": "mensaje"}`.

| Código | Cuándo |
|--------|--------|
| 400 | JSON inválido, faltan campos, email/teléfono inválido, imagen inválida, PUT incompleto |
| 404 | Contacto o ruta inexistente |
| 405 | Método no permitido (incluye header `Allow`) |
| 409 | Email o teléfono ya registrado en otro contacto |
| 413 | Cuerpo mayor a 4 MB |
| 500 | Error interno |

## Ejemplos con curl

```bash
# Crear
curl -i -X POST http://127.0.0.1:8000/api/contactos -H "Content-Type: application/json" \
  -d '{"nombre":"Ana","apellido":"Perez","telefono":"+5493811111111","email":"ana@gmail.com","categoria":"Personal"}'

# Listar con filtros
curl "http://127.0.0.1:8000/api/contactos?q=ana&categoria=Personal"

# Obtener / actualizar parcial / eliminar
curl http://127.0.0.1:8000/api/contactos/1
curl -X PATCH http://127.0.0.1:8000/api/contactos/1 -H "Content-Type: application/json" -d '{"categoria":"Familia"}'
curl -i -X DELETE http://127.0.0.1:8000/api/contactos/1
```

## Pruebas

- **Automáticas:** `python -m unittest discover` (22 tests, incluye `tests/test_api.py` que levanta un servidor real).
- **Postman:** importar `postman/Agenda_API.postman_collection.json` (ver `postman/LEEME.md`).
- **Resultados de una ejecución:** `docs/resultados_pruebas.md`.
