import unittest
from utils.validation import validar_email, validar_telefono

class TestValidation(unittest.TestCase):
    def test_email_valido(self):
        self.assertTrue(validar_email("ana@gmail.com"))

    def test_email_invalido(self):
        self.assertFalse(validar_email("ana@"))

    def test_telefono_valido(self):
        self.assertTrue(validar_telefono("+5493811234567"))

    def test_telefono_invalido(self):
        self.assertFalse(validar_telefono("381-123"))

if __name__ == "__main__":
    unittest.main()
