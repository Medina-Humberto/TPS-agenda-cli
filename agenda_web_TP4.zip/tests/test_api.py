"""Tests de la API REST: levantan un servidor real en un puerto libre."""
import json
import os
import shutil
import tempfile
import threading
import unittest
import urllib.error
import urllib.request

from services.contact_manager import ContactManager
from web import server

PNG = ("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==")
ANA = {"nombre": "Ana", "apellido": "Perez", "telefono": "+5493811111111", "email": "ana@gmail.com", "categoria": "Personal"}
JUAN = {"nombre": "Juan", "apellido": "Gomez", "telefono": "3812222222", "email": "juan@gmail.com", "categoria": "Trabajo"}


class TestAPI(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cwd = os.getcwd()
        cls.tmp = tempfile.mkdtemp()
        os.chdir(cls.tmp)  # agenda.csv y uploads/ quedan en una carpeta temporal
        server.manager = ContactManager()
        server.Handler.log_message = lambda *a, **k: None  # silenciar logs en los tests
        cls.srv = server.crear_servidor(port=0)
        cls.base = f"http://127.0.0.1:{cls.srv.server_address[1]}"
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()
        cls.srv.server_close()
        os.chdir(cls.cwd)
        shutil.rmtree(cls.tmp)

    def setUp(self):  # base limpia en cada test
        for f in os.listdir("uploads"):
            os.remove(os.path.join("uploads", f))
        if os.path.exists("agenda.csv"):
            os.remove("agenda.csv")

    def req(self, metodo, ruta, cuerpo=None, crudo=None):
        data = crudo if crudo is not None else (json.dumps(cuerpo).encode() if cuerpo is not None else None)
        r = urllib.request.Request(self.base + ruta, data=data, method=metodo, headers={"Content-Type": "application/json"})
        try:
            resp = urllib.request.urlopen(r)
        except urllib.error.HTTPError as e:
            resp = e
        cuerpo_resp = resp.read()
        try:
            cuerpo_resp = json.loads(cuerpo_resp)
        except ValueError:
            pass
        return resp.status if hasattr(resp, "status") else resp.code, cuerpo_resp, resp.headers

    def test_crear_y_obtener(self):
        s, c, h = self.req("POST", "/api/contactos", ANA)
        self.assertEqual(s, 201)
        self.assertEqual(h["Location"], f"/api/contactos/{c['id']}")
        s, c2, _ = self.req("GET", f"/api/contactos/{c['id']}")
        self.assertEqual((s, c2["email"]), (200, "ana@gmail.com"))

    def test_listar_y_filtros(self):
        self.req("POST", "/api/contactos", ANA)
        self.req("POST", "/api/contactos", JUAN)
        s, lista, h = self.req("GET", "/api/contactos")
        self.assertEqual((s, len(lista), h["X-Total-Count"]), (200, 2, "2"))
        self.assertEqual(len(self.req("GET", "/api/contactos?categoria=trabajo")[1]), 1)
        self.assertEqual(self.req("GET", "/api/contactos?q=ana")[1][0]["nombre"], "Ana")

    def test_validaciones_400(self):
        self.assertEqual(self.req("POST", "/api/contactos", {**ANA, "email": "ana@"})[0], 400)
        self.assertEqual(self.req("POST", "/api/contactos", {**ANA, "telefono": "abc"})[0], 400)
        s, err, _ = self.req("POST", "/api/contactos", {"nombre": "X"})
        self.assertEqual(s, 400)
        self.assertIn("apellido", err["error"])
        self.assertEqual(self.req("POST", "/api/contactos", crudo=b"{no es json")[0], 400)
        self.assertEqual(self.req("POST", "/api/contactos", crudo=b"[1,2]")[0], 400)

    def test_duplicado_409(self):
        self.req("POST", "/api/contactos", ANA)
        self.assertEqual(self.req("POST", "/api/contactos", {**JUAN, "email": "ANA@gmail.com"})[0], 409)
        _, j, _ = self.req("POST", "/api/contactos", JUAN)
        self.assertEqual(self.req("PATCH", f"/api/contactos/{j['id']}", {"telefono": ANA["telefono"]})[0], 409)

    def test_put_completo_y_patch_parcial(self):
        _, c, _ = self.req("POST", "/api/contactos", ANA)
        url = f"/api/contactos/{c['id']}"
        self.assertEqual(self.req("PUT", url, {"nombre": "Solo"})[0], 400)  # PUT exige todo
        s, nuevo, _ = self.req("PUT", url, {**ANA, "nombre": "Anita"})
        self.assertEqual((s, nuevo["nombre"]), (200, "Anita"))
        s, nuevo, _ = self.req("PATCH", url, {"categoria": "Familia"})
        self.assertEqual((s, nuevo["categoria"], nuevo["nombre"]), (200, "Familia", "Anita"))

    def test_404(self):
        for m in ("GET", "DELETE"):
            self.assertEqual(self.req(m, "/api/contactos/999")[0], 404)
        self.assertEqual(self.req("PATCH", "/api/contactos/999", {"nombre": "x"})[0], 404)
        self.assertEqual(self.req("GET", "/api/contactos/abc")[0], 404)
        self.assertEqual(self.req("GET", "/api/nada")[0], 404)

    def test_405(self):
        s, _, h = self.req("DELETE", "/api/contactos")
        self.assertEqual(s, 405)
        self.assertIn("GET", h["Allow"])

    def test_delete_204_y_luego_404(self):
        _, c, _ = self.req("POST", "/api/contactos", ANA)
        self.assertEqual(self.req("DELETE", f"/api/contactos/{c['id']}")[0], 204)
        self.assertEqual(self.req("GET", f"/api/contactos/{c['id']}")[0], 404)

    def test_imagen_ciclo_completo(self):
        _, c, _ = self.req("POST", "/api/contactos", {**ANA, "imagen_data": PNG})
        archivo = os.path.join("uploads", c["imagen"])
        self.assertTrue(os.path.isfile(archivo))
        self.assertEqual(self.req("GET", "/uploads/" + c["imagen"])[0], 200)
        _, c2, _ = self.req("PATCH", f"/api/contactos/{c['id']}", {"quitar_imagen": True})
        self.assertEqual(c2["imagen"], "")
        self.assertFalse(os.path.exists(archivo))  # se borró del disco

    def test_imagen_invalida_400_sin_huerfanos(self):
        malo = "data:image/png;base64,aG9sYQ=="  # "hola": no es imagen
        self.assertEqual(self.req("POST", "/api/contactos", {**ANA, "imagen_data": malo})[0], 400)
        self.assertEqual(os.listdir("uploads"), [])

    def test_rechazo_si_falla_no_deja_imagen_huerfana(self):
        self.req("POST", "/api/contactos", ANA)
        self.req("POST", "/api/contactos", {**ANA, "imagen_data": PNG})  # duplicado -> 409
        self.assertEqual(os.listdir("uploads"), [])

    def test_export_csv(self):
        self.req("POST", "/api/contactos", ANA)
        r = urllib.request.urlopen(self.base + "/api/export")
        texto = r.read().decode()
        self.assertTrue(r.headers["Content-Type"].startswith("text/csv"))
        self.assertTrue(texto.startswith("id,nombre,apellido,telefono,email,categoria,imagen"))
        self.assertIn("ana@gmail.com", texto)

    def test_path_traversal(self):
        for ruta in ("/uploads/../agenda.csv", "/static/../agenda.csv", "/uploads/%2e%2e/agenda.csv"):
            self.assertEqual(self.req("GET", ruta)[0], 404)

    def test_persistencia_csv(self):
        self.req("POST", "/api/contactos", ANA)
        self.assertIn("ana@gmail.com", open("agenda.csv", encoding="utf-8").read())


if __name__ == "__main__":
    unittest.main()
