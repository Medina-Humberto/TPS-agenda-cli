import base64
import os
import shutil
import tempfile
import unittest

from services.contact_manager import ContactManager
from services import image_store

# PNG de 1x1 píxel
PNG_B64 = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg=="
PNG_URL = "data:image/png;base64," + PNG_B64


class TestManagerWeb(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.mkdtemp()
        self.m = ContactManager(os.path.join(self.dir, "agenda.csv"))

    def tearDown(self):
        shutil.rmtree(self.dir)

    def test_crud_con_imagen_persistente(self):
        nombre_img = image_store.guardar_imagen(PNG_URL, carpeta=self.dir)
        c = self.m.add("Ana", "Perez", "+5493811111111", "ana@gmail.com", "Personal", nombre_img)
        # se relee desde el CSV
        guardado = ContactManager(self.m.db_file).get(c.id)
        self.assertEqual(guardado["imagen"], nombre_img)
        self.assertTrue(os.path.isfile(os.path.join(self.dir, nombre_img)))
        self.m.update(c.id, {"nombre": "Anita"})
        self.assertEqual(self.m.get(c.id)["nombre"], "Anita")
        self.assertTrue(self.m.delete(c.id, confirm=True))
        self.assertEqual(self.m.list_all(), [])

    def test_duplicado_en_update(self):
        self.m.add("A", "A", "111", "a@a.com", "x")
        b = self.m.add("B", "B", "222", "b@b.com", "x")
        with self.assertRaises(ValueError):
            self.m.update(b.id, {"email": "a@a.com"})

    def test_csv_viejo_sin_columna_imagen(self):
        with open(self.m.db_file, "w", encoding="utf-8") as f:
            f.write("id,nombre,apellido,telefono,email,categoria\n1,Ana,P,123,a@a.com,x\n")
        self.assertEqual(self.m.list_all()[0]["imagen"], "")

    def test_imagen_invalida(self):
        with self.assertRaises(ValueError):
            image_store.guardar_imagen("data:text/plain;base64," + base64.b64encode(b"hola").decode(), carpeta=self.dir)


if __name__ == "__main__":
    unittest.main()
