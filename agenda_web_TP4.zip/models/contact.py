from dataclasses import dataclass


@dataclass
class Contacto:
    id: int
    nombre: str
    apellido: str
    telefono: str
    email: str
    categoria: str
    imagen: str = ""  # nombre del archivo dentro de la carpeta uploads/

    def to_dict(self):
        return {
            "id": str(self.id),
            "nombre": self.nombre,
            "apellido": self.apellido,
            "telefono": self.telefono,
            "email": self.email,
            "categoria": self.categoria,
            "imagen": self.imagen,
        }
