"use strict";

const $ = (id) => document.getElementById(id);
const API = "/api/contactos";

let contactos = [];
let editandoId = null;     // null = creando
let imagenNueva = null;    // data URL de la imagen elegida
let quitarImagen = false;
let imagenActual = "";     // archivo actual del contacto en edición
let idAEliminar = null;

// ---------- utilidades ----------
const EMAIL_RE = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
const TEL_RE = /^\+?[0-9]+$/;
const COLORES = ["#4f46e5", "#0891b2", "#059669", "#d97706", "#db2777", "#7c3aed", "#dc2626", "#0d9488"];

function el(tag, props = {}, ...hijos) {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === "class") n.className = v;
    else if (k === "text") n.textContent = v;
    else if (k.startsWith("on")) n.addEventListener(k.slice(2), v);
    else n.setAttribute(k, v);
  }
  hijos.flat().forEach((h) => n.append(h));
  return n;
}

function toast(msg, esError = false) {
  const t = $("toast");
  t.textContent = msg;
  t.className = "toast" + (esError ? " error" : "");
  t.hidden = false;
  clearTimeout(toast._t);
  toast._t = setTimeout(() => (t.hidden = true), 3000);
}

async function api(url, opciones = {}) {
  const resp = await fetch(url, {
    headers: { "Content-Type": "application/json" },
    ...opciones,
  });
  const datos = await resp.json().catch(() => ({}));
  if (!resp.ok) throw new Error(datos.error || "Error inesperado");
  return datos;
}

function avatar(c, extra = "") {
  const caja = el("div", { class: "avatar " + extra, "aria-hidden": "true" });
  if (c.imagen) {
    caja.append(el("img", { src: "/uploads/" + encodeURIComponent(c.imagen), alt: "", loading: "lazy" }));
  } else {
    const iniciales = ((c.nombre || "?")[0] + ((c.apellido || "")[0] || "")).toUpperCase();
    caja.textContent = iniciales;
    caja.style.background = COLORES[(parseInt(c.id, 10) || 0) % COLORES.length];
  }
  return caja;
}

// ---------- listado ----------
async function cargar() {
  try {
    contactos = await api(API);
    actualizarCategorias();
    render();
  } catch (e) {
    toast(e.message, true);
  }
}

function actualizarCategorias() {
  const sel = $("filtro-categoria");
  const actual = sel.value;
  const cats = [...new Set(contactos.map((c) => c.categoria).filter(Boolean))].sort();
  sel.replaceChildren(el("option", { value: "", text: "Todas las categorías" }),
    ...cats.map((c) => el("option", { value: c, text: c })));
  sel.value = cats.includes(actual) ? actual : "";
}

function render() {
  const q = $("buscar").value.trim().toLowerCase();
  const cat = $("filtro-categoria").value;
  const visibles = contactos.filter((c) =>
    (!cat || c.categoria === cat) &&
    (!q || [c.nombre, c.apellido, c.telefono, c.email].some((v) => v.toLowerCase().includes(q))));

  const lista = $("lista");
  lista.replaceChildren(...visibles.map(tarjeta));
  $("vacio").hidden = visibles.length > 0;
  $("contador").textContent = `${visibles.length} de ${contactos.length} contactos`;
}

function tarjeta(c) {
  return el("article", { class: "card" },
    el("div", { class: "card__head" },
      avatar(c),
      el("div", {},
        el("h3", { class: "card__name", text: `${c.nombre} ${c.apellido}` }),
        el("span", { class: "badge", text: c.categoria }))),
    el("ul", { class: "card__data" },
      el("li", {}, "📞 ", el("a", { href: "tel:" + c.telefono, text: c.telefono })),
      el("li", {}, "✉️ ", el("a", { href: "mailto:" + c.email, text: c.email }))),
    el("div", { class: "card__actions" },
      el("button", { class: "btn btn--ghost btn--small", type: "button", text: "Editar", onclick: () => abrirForm(c) }),
      el("button", { class: "btn btn--ghost btn--small", type: "button", text: "Eliminar", onclick: () => pedirBorrado(c) })));
}

// ---------- formulario ----------
function pintarPreview() {
  const prev = $("preview");
  prev.replaceChildren();
  prev.style.background = "";
  const src = imagenNueva || (!quitarImagen && imagenActual ? "/uploads/" + encodeURIComponent(imagenActual) : "");
  if (src) {
    prev.append(el("img", { src, alt: "" }));
  } else {
    const n = ($("nombre").value[0] || "?").toUpperCase();
    const a = ($("apellido").value[0] || "").toUpperCase();
    prev.textContent = n + a;
    prev.style.background = COLORES[0];
  }
  $("quitar-imagen").hidden = !src;
}

function abrirForm(c = null) {
  editandoId = c ? c.id : null;
  imagenNueva = null;
  quitarImagen = false;
  imagenActual = c ? c.imagen : "";
  $("modal-titulo").textContent = c ? "Editar contacto" : "Nuevo contacto";
  for (const campo of ["nombre", "apellido", "telefono", "email", "categoria"]) {
    $(campo).value = c ? c[campo] : "";
    $(campo).classList.remove("invalid");
  }
  $("imagen").value = "";
  $("form-error").hidden = true;
  pintarPreview();
  $("modal").showModal();
  $("nombre").focus();
}

function validar() {
  const errores = [];
  const v = (id) => $(id).value.trim();
  const marcar = (id, malo) => $(id).classList.toggle("invalid", malo);

  marcar("nombre", !v("nombre")); marcar("apellido", !v("apellido")); marcar("categoria", !v("categoria"));
  if (!v("nombre") || !v("apellido")) errores.push("El nombre y el apellido son obligatorios.");
  if (!v("categoria")) errores.push("La categoría es obligatoria.");
  const telMal = !TEL_RE.test(v("telefono")); marcar("telefono", telMal);
  if (telMal) errores.push("El teléfono solo puede contener números y opcionalmente '+' al inicio.");
  const mailMal = !EMAIL_RE.test(v("email")); marcar("email", mailMal);
  if (mailMal) errores.push("El email no tiene un formato válido.");
  return errores;
}

// Reduce la imagen a 256 px para que el CSV/uploads queden livianos.
function redimensionar(archivo) {
  return new Promise((resolve, reject) => {
    if (!/^image\/(png|jpeg|gif|webp)$/.test(archivo.type)) return reject(new Error("Formato no soportado. Usá PNG, JPG, GIF o WEBP."));
    if (archivo.size > 8 * 1024 * 1024) return reject(new Error("La imagen es demasiado grande (máx. 8 MB)."));
    const url = URL.createObjectURL(archivo);
    const img = new Image();
    img.onload = () => {
      const lado = Math.min(256, Math.min(img.width, img.height));
      const canvas = document.createElement("canvas");
      canvas.width = canvas.height = lado;
      const recorte = Math.min(img.width, img.height);
      canvas.getContext("2d").drawImage(img, (img.width - recorte) / 2, (img.height - recorte) / 2, recorte, recorte, 0, 0, lado, lado);
      URL.revokeObjectURL(url);
      resolve(canvas.toDataURL("image/jpeg", 0.88));
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error("No se pudo leer la imagen.")); };
    img.src = url;
  });
}

$("imagen").addEventListener("change", async (e) => {
  const archivo = e.target.files[0];
  if (!archivo) return;
  try {
    imagenNueva = await redimensionar(archivo);
    quitarImagen = false;
    $("form-error").hidden = true;
    pintarPreview();
  } catch (err) {
    e.target.value = "";
    mostrarError(err.message);
  }
});

$("quitar-imagen").addEventListener("click", () => {
  imagenNueva = null;
  quitarImagen = true;
  $("imagen").value = "";
  pintarPreview();
});

["nombre", "apellido"].forEach((id) => $(id).addEventListener("input", () => { if (!imagenNueva && !imagenActual) pintarPreview(); }));

function mostrarError(msg) {
  const box = $("form-error");
  box.textContent = msg;
  box.hidden = false;
}

$("form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const errores = validar();
  if (errores.length) return mostrarError(errores.join(" "));

  const cuerpo = {};
  for (const campo of ["nombre", "apellido", "telefono", "email", "categoria"]) cuerpo[campo] = $(campo).value.trim();
  if (imagenNueva) cuerpo.imagen_data = imagenNueva;
  if (quitarImagen) cuerpo.quitar_imagen = true;

  const btn = $("guardar");
  btn.disabled = true;
  try {
    if (editandoId) await api(`${API}/${editandoId}`, { method: "PUT", body: JSON.stringify(cuerpo) });
    else await api(API, { method: "POST", body: JSON.stringify(cuerpo) });
    $("modal").close();
    toast(editandoId ? "Contacto actualizado" : "Contacto registrado");
    await cargar();
  } catch (err) {
    mostrarError(err.message);
  } finally {
    btn.disabled = false;
  }
});

$("cancelar").addEventListener("click", () => $("modal").close());
$("btn-nuevo").addEventListener("click", () => abrirForm());

// ---------- borrado ----------
function pedirBorrado(c) {
  idAEliminar = c.id;
  $("confirmar-texto").textContent = `¿Seguro que querés eliminar a ${c.nombre} ${c.apellido}? Esta acción no se puede deshacer.`;
  $("confirmar").showModal();
}
$("confirmar-no").addEventListener("click", () => $("confirmar").close());
$("confirmar-si").addEventListener("click", async () => {
  try {
    await api(`${API}/${idAEliminar}`, { method: "DELETE" });
    toast("Contacto eliminado");
    await cargar();
  } catch (err) {
    toast(err.message, true);
  }
  $("confirmar").close();
});

// ---------- filtros ----------
$("buscar").addEventListener("input", render);
$("filtro-categoria").addEventListener("change", render);

cargar();
